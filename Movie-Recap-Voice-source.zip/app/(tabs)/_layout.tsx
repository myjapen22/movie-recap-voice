import { Ionicons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";
import { useAppState } from "@/lib/app-state";
import { getCopy } from "@/lib/i18n";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const { language } = useAppState();
  const copy = getCopy(language);
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarActiveTintColor: "#A88DFF",
        tabBarInactiveTintColor: "#7C849E",
        tabBarStyle: {
          paddingTop: 7,
          paddingBottom: bottomPadding,
          height: 57 + bottomPadding,
          backgroundColor: "#0B0E1B",
          borderTopColor: "rgba(160, 175, 220, 0.14)",
          borderTopWidth: 1,
        },
        tabBarLabelStyle: { fontSize: 10, fontWeight: "600" },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{ title: copy.home, tabBarIcon: ({ color, size }) => <Ionicons name="home-outline" size={size} color={color} /> }}
      />
      <Tabs.Screen
        name="narrator"
        options={{ title: copy.narrator, tabBarIcon: ({ color, size }) => <Ionicons name="book-outline" size={size} color={color} /> }}
      />
      <Tabs.Screen
        name="history"
        options={{ title: copy.history, tabBarIcon: ({ color, size }) => <Ionicons name="time-outline" size={size} color={color} /> }}
      />
      <Tabs.Screen
        name="settings"
        options={{ title: copy.settings, tabBarIcon: ({ color, size }) => <Ionicons name="options-outline" size={size} color={color} /> }}
      />
      <Tabs.Screen name="kikivoice" options={{ href: null }} />
    </Tabs>
  );
}
